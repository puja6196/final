package com.nucleus.service;

import java.util.List;

import com.nucleus.model.Authorities18060126;
import com.nucleus.model.Customer18060126;
import com.nucleus.model.User18060126;



public interface ServiceDao {

	public void insertServiceDAO(Customer18060126 customer18060126);
	public boolean deleteServiceDAO(Customer18060126 customer18060126);
	public Customer18060126 viewServiceDAO(Customer18060126 customer18060126);
	public List<Customer18060126> viewAllServiceDAO();
	public void updateServiceDAO(Customer18060126 customer18060126);
	public boolean isPrimaryKey(Customer18060126 customer18060126);
	public boolean newServiceRegistration(User18060126 user18060126,Authorities18060126 authorities18060126);
}

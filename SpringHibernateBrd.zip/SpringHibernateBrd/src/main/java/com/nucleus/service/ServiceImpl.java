package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CustomerDao;
import com.nucleus.dao.UserDao;
import com.nucleus.model.Authorities18060126;
import com.nucleus.model.Customer18060126;
import com.nucleus.model.User18060126;


@Service
public class ServiceImpl implements ServiceDao{
	
	@Autowired
	CustomerDao customerDao;
	@Autowired
	UserDao userDao;
	@Transactional
	@Override
	public void insertServiceDAO(Customer18060126 customer18060126) {
		customerDao.insertCustomerDAO(customer18060126);		
	}
	@Transactional
	@Override
	public boolean deleteServiceDAO(Customer18060126 customer18060126) {
		return customerDao.deleteCustomerDAO(customer18060126);
	}
	@Transactional
	@Override
	public Customer18060126 viewServiceDAO(Customer18060126 customer18060126) {
		return customerDao.viewCustomerDAO(customer18060126);
	}
	@Transactional
	@Override
	public List<Customer18060126> viewAllServiceDAO() {

		return customerDao.viewAllCustomerDAO();
	}
	@Transactional
	@Override
	public void updateServiceDAO(Customer18060126 customer18060126) {
customerDao.updateCustomerDAO(customer18060126);
		
	}
	@Transactional
	@Override
	public boolean isPrimaryKey(Customer18060126 customer18060126) {

		return customerDao.isPrimaryKey(customer18060126);
	}
	
	@Transactional
	@Override
	public boolean newServiceRegistration(User18060126 user18060126, Authorities18060126 authorities18060126) {
		return userDao.newRegistration(user18060126, authorities18060126);
	}

}

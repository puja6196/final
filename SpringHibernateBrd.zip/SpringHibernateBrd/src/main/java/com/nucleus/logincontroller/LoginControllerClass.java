package com.nucleus.logincontroller;

import javax.servlet.http.HttpServletRequest;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Authorities18060126;
import com.nucleus.model.User18060126;





@Controller
public class LoginControllerClass
{

	
	@RequestMapping("/accdenied")
	public String errorPageHandler()
	{
		return "errorpage";
	}
@RequestMapping("/login")
public ModelAndView loginPageHandler()
{
	return new ModelAndView("/login");
}

@RequestMapping("/loginfailure")
public ModelAndView loginFailurehandler()
{
	return new ModelAndView("login","message","Incorrect Username or Password");	
}



@RequestMapping("/logout")
public ModelAndView logoutHandler()
{
	return new ModelAndView("login","message","Logout Successfull");
}

@RequestMapping("/authorityHandler")
public ModelAndView authorityHandler(HttpServletRequest request)
{
	String targetUrl=null;
	
	if(request.isUserInRole("ROLE_ADMIN"))
	{		
		return new ModelAndView("adminhome");
	}
	else
		if(request.isUserInRole("ROLE_USER"))
		{
			targetUrl="splitpage";
		}
	return new ModelAndView(targetUrl);
}



}

package com.nucleus.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.Authorities18060126;
import com.nucleus.model.Customer18060126;
import com.nucleus.model.User18060126;
import com.nucleus.service.ServiceDao;




@SessionAttributes("username")
@Controller
public class CustomerController {
	@Autowired
	ServiceDao serviceDao;
	
	@ModelAttribute("username")
	public String username()
	{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return auth.getName();
	}
	
	@RequestMapping("/splitpage")
	public String makerHandler1()
	{
		return "splitpage";
	}
	
	@RequestMapping("/adminhome")
	public String adminHomeHandler()
	{
		return "adminhome";
	}
	
	@RequestMapping("/newregistration")
	public String newRegistraionHandler(HttpServletRequest request,User18060126 user18060126,Authorities18060126 authorities18060126)
	{
		return "newregistration";
	}
	
	
	
	
	long millis =System.currentTimeMillis();
	Date date=new Date(millis);
	
	/*Insert*/
	@RequestMapping("/insert")
	public String insertHandler1(Customer18060126 customer18060126)
	{
		return "insertpage";
	}
	@RequestMapping("/customerdetailssubmit")
	public ModelAndView insertHandler2(@Valid Customer18060126 customer18060126,BindingResult result)
	{
		customer18060126.setCreatedBy(username());
		customer18060126.setRegistrationDate(date);
		if(result.hasErrors())
		{
			return new ModelAndView("insertpage");
		}	
		if(serviceDao.isPrimaryKey(customer18060126))
		{
			serviceDao.insertServiceDAO(customer18060126);
			return new ModelAndView("splitpage","message","Successfully Inserted");	
		}
		return new ModelAndView("insertpage","message","Unique Customer Code Found");
	}
	/*Insert*/
	////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	/*Delete*/
	@RequestMapping("/delete")
	public String deleteHandler1(Customer18060126 customer18060126)
	{
		return "deletepage";
	}
	@RequestMapping("/deletedetails")
	public ModelAndView deleteHandler2(Customer18060126 customer18060126)
	{
		/*boolean check=serviceDao.deleteServiceDAO(customer18060126);
	
		if(check==true)
		return new ModelAndView("userpage","message","Successfully Deleted");
		else
			return new ModelAndView("deletepage","message","NO SUCH DATA FOUND");*/
		if(serviceDao.deleteServiceDAO(customer18060126))
		return new ModelAndView("splitpage","message","Successfully Deleted");
		else
			return new ModelAndView("deletepage","message","No Such Record Found");
	}
	
	/*Delete*/
	////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	
	/*View*/
	@RequestMapping("/view")
	public String viewHandler1(Customer18060126 customer18060126)
	{
		return "viewpage";
	}
	@RequestMapping("/viewdetails")
	public ModelAndView viewHandler2(Customer18060126 customer18060126)
	{
		Customer18060126 customer3=serviceDao.viewServiceDAO(customer18060126);
		if(customer3==null)
		{
			return new ModelAndView("viewpage","message","No Such Record Found");
		}
		return new ModelAndView("viewbyid","customer18060126",customer3);
	}
	/*View*/

	
	////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	/*Update*/
	@RequestMapping("/update")
	public String updateHandler1(Customer18060126 customer18060126)
	{
		return "updatepage";
	}
	@RequestMapping("/updatedetails")
	public ModelAndView updateHandler2(@ModelAttribute("customer18060126") Customer18060126 customer18060126)
	{
		Customer18060126 customer3=serviceDao.viewServiceDAO(customer18060126);
		if(customer3==null)
		{
			return new ModelAndView("updatepage","message","No Such Record Found");
		}
		return new ModelAndView("editdetailpage","customer18060126",customer3);
		
	}
	@RequestMapping("/updatedetailssubmit")
	public ModelAndView updateHandler3(@Valid Customer18060126 customer18060126,BindingResult result )
	{
		System.out.println("abcdddddddd--"+customer18060126.getCreatedBy()+" "+customer18060126.getRegistrationDate());
		//customer18060126.setModifiedDate(date);
	/*	if(result.hasErrors())
		{
			return new ModelAndView("editdetailpage");
		}*/
		serviceDao.updateServiceDAO(customer18060126);
		return new ModelAndView("splitpage","message","Successfully Updated");
	}
	/*Update*/
	////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
	/*ViewAll*/
	@RequestMapping("/viewall")
	public ModelAndView viewallHandler1(Customer18060126 customer18060126)
	{
		List<Customer18060126> customer1806012=serviceDao.viewAllServiceDAO();
		if(customer18060126==null)
		{
			return new ModelAndView("splitpage","message","NO DATA FOUND");
		}
		return new ModelAndView("viewallpage","customer18060126",customer1806012);
	}
	/*ViewAll*/
	
	
	////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////
	@RequestMapping("/userdetailssubmit")
	public ModelAndView adminPageHandler(User18060126 user18060126,Authorities18060126 authorities18060126)
	{
		if(serviceDao.newServiceRegistration(user18060126, authorities18060126))
		return new ModelAndView("adminhome","message","Successfully Inserted");
		else
			return new ModelAndView("newregistration","message","Unique User Code Found");
	}
	
	
	
	
	
	//////////////////////////////////////////////
	/////////////////////////////////////////////
}

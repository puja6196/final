package com.nucleus.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;




@Entity
public class User18060126 {
	
	
	@Id
	private String userId;
	@Column(nullable=false)
	private String userPassword;
	@Column(nullable=false,length=1)
	private int enabled;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="roleId")
	private Authorities18060126 authorities18060126;
	
	public Authorities18060126 getAuthorities18060126() {
		return authorities18060126;
	}
	public void setAuthorities18060126(Authorities18060126 authorities18060126) {
		this.authorities18060126 = authorities18060126;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	
	@Override
	public String toString() {
		return "User18060126 [userId=" + userId + ", userPassword=" + userPassword + ", enabled=" + enabled
				+ ", authorities18060126=" + authorities18060126 + "]";
	}

}

package com.nucleus.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;


import org.hibernate.validator.constraints.Email;


@SuppressWarnings("serial")
@Entity
public class Customer18060126 implements Serializable {
	
	@Id
	@Column(length=10)
	private Long customerCode;
	@Column(length=30,nullable=false)
	private String customerName;
	@Column(length=100,nullable=false)
	private String customerAddress;
	@Pattern(regexp="[0-9]{6,6}")
	@Column(length=6,nullable=false)
	private String customerPinCode;
	@Email
	@Column(length=100,nullable=false)
	private String customerEmail;
	@Pattern(regexp="[0-9]{10,20}")
	@Column(length=20,nullable=true)
	private String contactNumber;
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	private Date registrationDate;
	@Column(nullable=false)
	private String createdBy;
	@Column(nullable=true)
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;
	public Long getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(Long customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Override
	public String toString() {
		return "Customer18060126 [customerCode=" + customerCode + ", customerName=" + customerName
				+ ", customerAddress=" + customerAddress + ", customerPinCode=" + customerPinCode + ", customerEmail="
				+ customerEmail + ", contactNumber=" + contactNumber + ", registrationDate=" + registrationDate
				+ ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate + "]";
	}
	
	
	
}

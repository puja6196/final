package com.nucleus.dao;

import java.sql.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.nucleus.model.Customer18060126;



@Repository
public class CustomerRdbmsDaoImpl implements CustomerDao {

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public void insertCustomerDAO(Customer18060126 customer18060126) {
		sessionFactory.getCurrentSession().persist(customer18060126);	
	}
	@Transactional
	@Override
	public boolean deleteCustomerDAO(Customer18060126 customer18060126) {
	
		Customer18060126 customer=(Customer18060126)sessionFactory.getCurrentSession().get(Customer18060126.class,customer18060126.getCustomerCode());
		if(customer!=null)
		{
		sessionFactory.getCurrentSession().delete(customer);
		return true;
		}
		return false;
	}

	@Override
	public Customer18060126 viewCustomerDAO(Customer18060126 customer18060126) {
	return (Customer18060126)sessionFactory.getCurrentSession().get(Customer18060126.class, customer18060126.getCustomerCode());

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer18060126> viewAllCustomerDAO() {
		List<Customer18060126> customer18060126=null;

		try
		{
			Query query=sessionFactory.getCurrentSession().createQuery("from Customer18060126");
			customer18060126=query.list();
		}
		catch (Exception e) {
			return customer18060126;
		}
		return customer18060126;
	}

	@Override
	public void updateCustomerDAO(Customer18060126 customer18060126) {
		long millis =System.currentTimeMillis();
		Date date=new Date(millis);
		String hql = "Update Customer18060126 set customerName=:customerName,customerAddress=:customerAddress,customerPinCode=:customerPinCode,customerEmail=:customerEmail,contactNumber=:contactNumber,modifiedDate=:modifiedDate where customerCode=:customerCode";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		query.setParameter("customerName",customer18060126.getCustomerName());
		query.setParameter("customerAddress",customer18060126.getCustomerAddress());
		query.setParameter("customerPinCode",customer18060126.getCustomerPinCode());
		query.setParameter("customerEmail",customer18060126.getCustomerEmail());
		query.setParameter("contactNumber",customer18060126.getContactNumber());
		query.setParameter("modifiedDate",date);
		query.setParameter("customerCode",customer18060126.getCustomerCode());
		query.executeUpdate();
		
	}

	@Override
	public boolean isPrimaryKey(Customer18060126 customer18060126) {
		Customer18060126 customer=(Customer18060126)sessionFactory.getCurrentSession().get(Customer18060126.class,customer18060126.getCustomerCode());
		if(customer!=null)
			return false;
		return true;
	}

}

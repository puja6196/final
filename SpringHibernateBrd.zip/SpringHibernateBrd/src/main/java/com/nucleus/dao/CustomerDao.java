package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Authorities18060126;
import com.nucleus.model.Customer18060126;
import com.nucleus.model.User18060126;

public interface CustomerDao {

	public void insertCustomerDAO(Customer18060126 customer18060126);
	public boolean deleteCustomerDAO(Customer18060126 customer18060126);
	public Customer18060126 viewCustomerDAO(Customer18060126 customer18060126);
	public List<Customer18060126> viewAllCustomerDAO();
	public void updateCustomerDAO(Customer18060126 customer18060126);
	public boolean isPrimaryKey(Customer18060126 customer18060126);
	
}

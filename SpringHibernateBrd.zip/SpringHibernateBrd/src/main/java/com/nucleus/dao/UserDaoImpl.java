package com.nucleus.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import com.nucleus.model.Authorities18060126;
import com.nucleus.model.User18060126;

@Repository
public class UserDaoImpl implements UserDao {
	
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	@Override
	public boolean newRegistration(User18060126 user18060126, Authorities18060126 authorities18060126) 
	{	
		User18060126 user=(User18060126)sessionFactory.getCurrentSession().get(User18060126.class,user18060126.getUserId());
		if(user!=null)
		{
			return false;
		}
		
		if(authorities18060126.getRole().contains("ROLE_ADMIN"))
		{
			
			String password=enCodePwd(user18060126.getUserPassword());
			user18060126.setUserPassword(password);
		authorities18060126.setRoleId(1);
		Authorities18060126 au=(Authorities18060126)sessionFactory.getCurrentSession().get(Authorities18060126.class, authorities18060126.getRoleId());
		if(au!=null)
		{
			user18060126.setAuthorities18060126(au);
			sessionFactory.getCurrentSession().saveOrUpdate(user18060126);
			return true;
		}
		user18060126.setAuthorities18060126(authorities18060126);
		sessionFactory.getCurrentSession().persist(user18060126);
		}
		else
			if(authorities18060126.getRole().contains("ROLE_USER"))
			{
				String password=enCodePwd(user18060126.getUserPassword());
				user18060126.setUserPassword(password);
			authorities18060126.setRoleId(2);
			Authorities18060126 au=(Authorities18060126)sessionFactory.getCurrentSession().get(Authorities18060126.class, authorities18060126.getRoleId());
			if(au!=null)
			{
				user18060126.setAuthorities18060126(au);
				sessionFactory.getCurrentSession().saveOrUpdate(user18060126);
				return true;
			
			}
			user18060126.setAuthorities18060126(authorities18060126);
			sessionFactory.getCurrentSession().persist(user18060126);
			}
		return true;
	}
////////////////////////////////////////////////////////////////
	
	
	
	
	@Override
	public String enCodePwd(String pwd) {
		return bCryptPasswordEncoder.encode(pwd);
		
	}
	

}

package com.nucleus.dao;

import com.nucleus.model.Authorities18060126;
import com.nucleus.model.User18060126;

public interface UserDao {
	public boolean newRegistration(User18060126 user18060126,Authorities18060126 authorities18060126);
	public  String enCodePwd(String pwd);
}

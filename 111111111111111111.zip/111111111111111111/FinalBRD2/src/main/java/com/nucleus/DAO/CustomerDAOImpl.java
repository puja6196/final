package com.nucleus.DAO;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.nucleus.model.Customer12;


@Repository
public class CustomerDAOImpl implements CustomerDAO
{ 	@Autowired
	SessionFactory sessionFactory;
  

//********************************************* new user ********************************************************
	@Transactional
	public void newUser(Customer12 customer12)
	{ 
		
		customer12.setRegistrationDate(new SimpleDateFormat("dd/MMM/YYYY").format(new java.util.Date()));
		sessionFactory.getCurrentSession().save(customer12);
		
	}

	
	//******************************** delete ***********************************************************************
	@Transactional
	public void delete(String customerCode)
	{
		
	 Customer12 customer12=(Customer12) sessionFactory.getCurrentSession().get(Customer12.class,customerCode);
		
		sessionFactory.getCurrentSession().delete(customer12);
	}

	//*********************************view*********************************************************************
	 
	@Transactional
	public Customer12 view(String customerCode)
	{
		
	Customer12 customer= (Customer12) sessionFactory.getCurrentSession().get(Customer12.class,customerCode);
	return customer;
		
		
	}

	//**********************************view update****************************************************************
	
@Transactional
public Customer12 viewUpdate(String customerCode)
{
	
	
	Customer12 customer123= (Customer12) sessionFactory.getCurrentSession().get(Customer12.class,customerCode);
	return customer123;


}
//**************************************update***************************************************
@Transactional
public	 void Update(Customer12 customer12)
{
	customer12.setModifiedDate(new SimpleDateFormat("dd/MMM/YYYY").format(new java.util.Date()));
	sessionFactory.getCurrentSession().update(customer12);
	

}
//************************************** view all *******************************************

@Transactional
public List<Customer12> viewAll()
{		
		@SuppressWarnings("unchecked")
		List<Customer12> list1=sessionFactory.getCurrentSession().createQuery("from Customer12").list();
		return list1;
	
}
	
}

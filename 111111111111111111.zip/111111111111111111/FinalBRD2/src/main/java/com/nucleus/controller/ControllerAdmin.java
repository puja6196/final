package com.nucleus.controller;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.DAO.UserDAO;
import com.nucleus.model.AuthorityPuja;
import com.nucleus.model.UserPuja;
@Controller
public class ControllerAdmin 
{
	@Autowired
	UserDAO userDAO;
	
   @RequestMapping("/Admin")
   public ModelAndView handler1(UserPuja userPuja,AuthorityPuja authorityPuja)
   {
	System.out.println("oooooooooooooooooooooo");
	return new ModelAndView( "AdminPage");
	  
   }
	
   @RequestMapping("/AdminReturn")
   public String handler2(UserPuja userPuja,AuthorityPuja authorityPuja)
   {
	   
	   
	System.out.println("ddddddddddddddddddddddddddddd");   
	   
	userDAO.saveData(userPuja,authorityPuja);
	return "success";
	  
   }
	
	
	
	
	
}

package com.nucleus.servie;

import org.springframework.stereotype.Repository;

import com.nucleus.model.AuthorityPuja;
import com.nucleus.model.UserPuja;

@Repository
public interface UserServiceDAO
{
	public boolean saveData(UserPuja userPuja, AuthorityPuja authorityPuja);

}

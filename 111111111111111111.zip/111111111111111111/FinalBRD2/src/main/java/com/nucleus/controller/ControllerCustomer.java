package com.nucleus.controller;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.DAO.CustomerDAO;

import com.nucleus.model.Customer12;

@Controller
public class ControllerCustomer
{ 
	@Autowired
	CustomerDAO customerDAO;
	
//***************************************** new user ******************************************************************************	
 @RequestMapping("/Menubar11")
 public String handler1()
 {
	
	return "SplitPage";
	 
 }
 @RequestMapping("/Menubar")
 public String handler111()
 {
	 return "Menubar1";
	  
	 
 }

 
 @RequestMapping("/newuser")
 public ModelAndView handler2(Customer12 customer12)
 {
	return new ModelAndView("NewUser");
	 
 }
 @RequestMapping("/submit")
 public ModelAndView handler3(@Valid Customer12 customer12,BindingResult result )
 {
	 if(result.hasErrors())
	 {
		 return new ModelAndView("NewUser");
		 
	 }
	 

		 customerDAO.newUser(customer12);
	return new ModelAndView("success");
	 
 }
 
 
 //************************************* delete ***************************************************************************************
 
 @RequestMapping("/delete")
 public ModelAndView handler4(Customer12 customer12)
 {
	
	return new ModelAndView("Deletec");
	
 }
 
 @RequestMapping("/submit2")
 
 public String handler5(@RequestParam("customerCode")String customerCode)
 {
	customerDAO.delete(customerCode);
	return ("delete11");
 }
//*************************************** view ************************************************************************************
  
 @RequestMapping("/viewcon")
 public ModelAndView handler6(Customer12 customer12)
 {
	return new ModelAndView ("viewc");
	 
	
 }
 
 
@RequestMapping("/submit3")
public ModelAndView handler7(@RequestParam("customerCode")String customerCode)
{   
	
	Customer12 customer12=customerDAO.view(customerCode);
	return new ModelAndView("view","customer",customer12);
	 
	
}
 

//********************************************* update *************************************************************************** 
 

@RequestMapping("/updatecon")
public String handler9(Customer12 customer12)
{
	return "updatei";
}

@RequestMapping("/updatecustomer")
public ModelAndView handler10(@RequestParam("customerCode")String customerCode)
{   
    
	 
		Customer12 customer12=customerDAO.viewUpdate(customerCode);

		return new ModelAndView("update1","customer",customer12);
	
}


@RequestMapping("/update23")
public String handler11(Customer12 customer12)
{   
	
		customerDAO.Update(customer12);
	    
		return "updaterecord1";
		
	
	
}
//********************************** view all *****************************************************
@RequestMapping("/viewall")
public ModelAndView handler8(Customer12 customer12)
{   
	
	List<Customer12> list=customerDAO.viewAll();
	return new ModelAndView("viewallc","list",list);
	 
	
}


 
}

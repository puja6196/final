package com.nucleus.servie;

import org.springframework.stereotype.Repository;

import com.nucleus.model.AuthorityPuja;
import com.nucleus.model.UserPuja;

@Repository
public class UserServiceDAOImpl implements UserServiceDAO
{

	@Override
	public boolean saveData(UserPuja userPuja, AuthorityPuja authorityPuja) {
		// TODO Auto-generated method stub
		return true;
	}

}

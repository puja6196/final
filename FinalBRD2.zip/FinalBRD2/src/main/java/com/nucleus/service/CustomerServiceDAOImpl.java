package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.DAO.CustomerDAO;
import com.nucleus.model.Customer12;
@Repository
public class CustomerServiceDAOImpl implements CustomerServiceDAO
{
	
	
	@Autowired
	CustomerDAO customerDAO;

	@Override
	public Boolean newUser(Customer12 customer12) {
		
		return customerDAO.newUser(customer12);
		
	}

	@Override
	public Boolean delete(String customerCode) {
		
		return customerDAO.delete(customerCode);
	}

	@Override
	public Customer12 viewUpdate(String usercode) {
		
		return customerDAO.viewUpdate(usercode);
	}

	@Override
	public Customer12 view(String customerCode) {
	
		return customerDAO.view(customerCode);
	}

	@Override
	public void Update(Customer12 customer12) {
		customerDAO.Update(customer12);
		
	}

	@Override
	public List<Customer12> viewAll() {
		
		return customerDAO.viewAll();
	}

}

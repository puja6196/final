package com.nucleus.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.DAO.UserDAO;
import com.nucleus.model.AuthorityPuja;
import com.nucleus.model.UserPuja;

@Repository
public class UserServiceDAOImpl implements UserServiceDAO
{
    @Autowired
    UserDAO userDAO;
	@Override
	public boolean saveData(UserPuja userPuja, AuthorityPuja authorityPuja)
	{
            return  userDAO.saveData(userPuja, authorityPuja);
		
	}

}

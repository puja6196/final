package com.nucleus.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer12;

@Repository
public interface CustomerServiceDAO
{
	public Boolean newUser(Customer12 customer12);
	
	public Boolean delete(String customerCode);
	

	public Customer12 viewUpdate(String usercode);

	public Customer12 view(String customerCode);

	public void Update(Customer12 customer12);

	public List<Customer12> viewAll();
}

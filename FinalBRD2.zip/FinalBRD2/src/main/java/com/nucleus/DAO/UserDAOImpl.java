package com.nucleus.DAO;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.AuthorityPuja;
import com.nucleus.model.UserPuja;
@Repository
public class UserDAOImpl implements UserDAO
{

	
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	@Override
	public boolean saveData(UserPuja userPuja, AuthorityPuja authorityPuja)
	{
		
		
		System.out.println("hellllllo"+authorityPuja);
	   UserPuja userPuja1=(UserPuja) sessionFactory.getCurrentSession().get(UserPuja.class,userPuja.getUserId());
	   if(userPuja1!=null)
	   {
		   return false;
		  	   
	   }
	   	
	   if(authorityPuja.getRole().contains("ROLE_USER"))
	   {
		   String password=enCodePwd(userPuja.getPassword());
		   userPuja.setPassword(password);
		   authorityPuja.setRoleId("1");
		   userPuja.setAuthorityPuja(authorityPuja);
		   sessionFactory.getCurrentSession().saveOrUpdate(userPuja);
		}
		
	   else
		   
		   
		   if(authorityPuja.getRole().contains("ROLE_ADMIN"))
		   {
			   String password=enCodePwd(userPuja.getPassword());
			   userPuja.setPassword(password);
			   authorityPuja.setRoleId("2");
			   userPuja.setAuthorityPuja(authorityPuja);
				sessionFactory.getCurrentSession().saveOrUpdate(userPuja);
			}
	return true;   
	
	}	   
		 
	   private String enCodePwd(String password)
	   {

			BCryptPasswordEncoder bCrypt=new BCryptPasswordEncoder();
			return bCrypt.encode(password);
		
	}

   
	
}



package com.nucleus.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;


import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.NumberFormat;
@Entity
public class Customer12
{  @Id   
@Length(min=3,max=10)
    private String customerCode;
    @NotNull
@Length(min=3,max=30)
private String customerName;
    @NotNull
@Length(min=5,max=100)
private String customerAddress;

    @NotNull
@NumberFormat
private String customerPinCode;
    @NotNull
@Email
@Length(min=5,max=100)
private String customerEmail;
    @NotNull
@NumberFormat
private String contactNumber;
 
private String registrationDate;
private String createdBy;
private String modifiedDate;
public String getCustomerCode() {
	return customerCode;
}
public void setCustomerCode(String customerCode) {
	this.customerCode = customerCode;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getCustomerAddress() {
	return customerAddress;
}
public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}
public String getCustomerPinCode() {
	return customerPinCode;
}
public void setCustomerPinCode(String customerPinCode) {
	this.customerPinCode = customerPinCode;
}
public String getCustomerEmail() {
	return customerEmail;
}
public void setCustomerEmail(String customerEmail) {
	this.customerEmail = customerEmail;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getRegistrationDate() {
	return registrationDate;
}
public void setRegistrationDate(String date) {
	this.registrationDate = date;
}
public String getCreatedBy() {
	return createdBy;
}
public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}
public String getModifiedDate() {
	return modifiedDate;
}
public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
}
@Override
public String toString() {
	return "Customer12 [customerCode=" + customerCode + ", customerName=" + customerName + ", customerAddress="
			+ customerAddress + ", customerPinCode=" + customerPinCode + ", customerEmail=" + customerEmail
			+ ", contactNumber=" + contactNumber + ", registrationDate=" + registrationDate + ", createdBy=" + createdBy
			+ ", modifiedDate=" + modifiedDate + "]";
}

	
}
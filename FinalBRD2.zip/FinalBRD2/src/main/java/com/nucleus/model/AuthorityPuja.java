
package com.nucleus.model;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class AuthorityPuja
{
	
	@Id
	
	private String roleId;
	private String role;
	
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	
	
	
}

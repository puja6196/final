package com.nucleus.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class UserPuja
{
	@Id
	private String userId;
	
	private String password;
	private int enabled;
	@JoinColumn(name="roleId")
    @ManyToOne(cascade = CascadeType.ALL)
	private AuthorityPuja authorityPuja;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public AuthorityPuja getAuthorityPuja() {
		return authorityPuja;
	}
	public void setAuthorityPuja(AuthorityPuja authorityPuja) {
		this.authorityPuja = authorityPuja;
	}
	@Override
	public String toString() {
		return "UserPuja [userId=" + userId + ", password=" + password + ", enabled=" + enabled + ", authorityPuja="
				+ authorityPuja + "]";
	}
	
	

}

package com.nucleus.controller;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.AuthorityPuja;
import com.nucleus.model.UserPuja;
import com.nucleus.service.UserServiceDAO;
@Controller
public class ControllerAdmin 
{
	
	final static Logger logger = Logger.getLogger(ControllerAdmin.class);

	@Autowired
	UserServiceDAO userServiceDAO;
	
   @RequestMapping("/Admin")
   public ModelAndView handler1(UserPuja userPuja,AuthorityPuja authorityPuja)
   {
   
	return new ModelAndView( "Admin1");
	  
   }
   
   @RequestMapping("/New")
   public ModelAndView handler22(UserPuja userPuja,AuthorityPuja authorityPuja)
   {
	
	return new ModelAndView( "AdminPage");
	  
   }
   
   @RequestMapping("/AdminReturn")
   public String handler2(UserPuja userPuja,AuthorityPuja authorityPuja)
   {
	   
    logger.info(userServiceDAO.saveData(userPuja,authorityPuja));
	return "success";
	  
   }
	
	
	
	
	
}

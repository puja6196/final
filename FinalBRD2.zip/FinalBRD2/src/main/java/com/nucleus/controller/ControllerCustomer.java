package com.nucleus.controller;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.DAO.CustomerDAO;

import com.nucleus.model.Customer12;
import com.nucleus.service.CustomerServiceDAO;

@Controller
public class ControllerCustomer
{ 
	@Autowired
	CustomerServiceDAO customerServiceDAO;;
	
//***************************************** new user ******************************************************************************	
 @RequestMapping("/Menubar11")
 public String handler1()
 {
	
	return "SplitPage";
	 
 }
 @RequestMapping("/Menubar")
 public String handler111()
 {
	 return "Menubar1";
	  
	 
 }

 
 @RequestMapping("/newuser")
 public ModelAndView handler2(Customer12 customer12)
 {
	return new ModelAndView("NewUser");
	 
 }
 @RequestMapping("/submit")
 public ModelAndView handler3(@Valid Customer12 customer12,BindingResult result )
 {
	 if(result.hasErrors())
	 {
		 return new ModelAndView("NewUser");
		 
	 }
	 
     
	Boolean cus12= customerServiceDAO.newUser(customer12);
	if(cus12!=null)
	{
	return new ModelAndView("success");
	}
	
	else
	
		
		return new ModelAndView("newError","E1","customer already exists");
		
	

	
	
	
 }
 
 
 //************************************* delete ***************************************************************************************
 
 @RequestMapping("/delete")
 public ModelAndView handler4(Customer12 customer12)
 {
	
	return new ModelAndView("Deletec");
	
 }
 
 @RequestMapping("/submit2")
 
 public ModelAndView handler5(@RequestParam("customerCode")String customerCode)
 {
	Boolean cust=customerServiceDAO.delete(customerCode);
	if(cust==true)
	{
	return new ModelAndView("delete11");
	}
	
	return new ModelAndView("ERROR","error","Record not found");

		
	
 }
//*************************************** view ************************************************************************************
  
 @RequestMapping("/viewcon")
 public ModelAndView handler6(Customer12 customer12)
 {
	return new ModelAndView ("viewc");
	 
	
 }
 
 
@RequestMapping("/submit3")
public ModelAndView handler7(@RequestParam("customerCode")String customerCode)
{   
	
	Customer12 customer12=customerServiceDAO.view(customerCode);
	if(customer12!=null)
	{
	return new ModelAndView("view","customer",customer12);
	}
	else
		
	return new ModelAndView("ERROR","error","Record not found");	
		
		
		
}
 

//********************************************* update *************************************************************************** 
 

@RequestMapping("/updatecon")
public String handler9(Customer12 customer12)
{
	return "updatei";
}

@RequestMapping("/updatecustomer")
public ModelAndView handler10(@RequestParam("customerCode")String customerCode)
{   
    
	 
		Customer12 customer12=customerServiceDAO.viewUpdate(customerCode);

		return new ModelAndView("update1","customer",customer12);
	
}


@RequestMapping("/update23")
public String handler11(Customer12 customer12)
{   
	
	customerServiceDAO.Update(customer12);
	    
		return "updaterecord1";
		
	
	
}
//********************************** view all *****************************************************
@RequestMapping("/viewall")
public ModelAndView handler8(Customer12 customer12)
{   
	
	List<Customer12> list=customerServiceDAO.viewAll();
	return new ModelAndView("viewallc","list",list);
	 
	
}


 
}
